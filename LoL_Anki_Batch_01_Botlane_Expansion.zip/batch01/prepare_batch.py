#!/usr/bin/env python3
"""Merge an editorial card batch into LoL Anki v4 after downloading matching Riot media.

Run next to the existing v4 project: the batch01 folder is inside the v4 project.
- Does not invent unavailable animations.
- Keeps existing card IDs and fields intact.
- Safe to rerun; writes a backup before the first merge.
"""
from __future__ import annotations
import csv, pathlib, shutil, sys

HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent
DOWNLOADS=HERE/'downloads'
SOURCE=HERE/'new_cards.csv'
MASTER=ROOT/'cards.csv'
MEDIA=ROOT/'media'
REPORT=HERE/'media_check.csv'


def read_csv(p,delimiter=','):
    with p.open('r',newline='',encoding='utf-8-sig') as f:
        r=csv.DictReader(f,delimiter=delimiter)
        return list(r), r.fieldnames


def write_csv(p,rows,cols):
    with p.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=cols)
        w.writeheader();w.writerows(rows)


def copy_to(src, rel):
    target=ROOT/rel
    if not src.is_file() or not target.resolve().is_relative_to(MEDIA.resolve()):
        return ''
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.is_file() or target.stat().st_size != src.stat().st_size:
        shutil.copy2(src,target)
    return rel.as_posix() if isinstance(rel,pathlib.Path) else str(rel).replace('\\','/')


def main():
    if not MASTER.is_file():
        print('ERROR: Unpack the batch01 folder INSIDE your existing v4 project (next to cards.csv and build_deck.py).')
        return 2
    if not (ROOT/'build_deck.py').is_file():
        print('ERROR: build_deck.py missing from parent v4 project.')
        return 2
    manifest=DOWNLOADS/'manifest.csv'
    if not manifest.is_file():
        print('ERROR: No batch01/downloads/manifest.csv. Run 01_fetch_media.bat first.')
        return 2
    media_rows, _ = read_csv(manifest,delimiter=';')
    record_index={(r['champion'].lower(),r['slot'].upper()):r for r in media_rows}
    wanted, cols=read_csv(SOURCE)
    existing, mastercols=read_csv(MASTER)
    if cols!=mastercols:
        print('ERROR: v4 cards.csv fields differ from this batch. No changes made.')
        return 2
    if len({r['id'] for r in existing})!=len(existing):
        print('ERROR: Existing cards have duplicate IDs. No changes made.')
        return 2
    changes=[]; checks=[]; missing=[]
    for row in wanted:
        row=dict(row)
        key=(row['champion'].lower(),row['slot'].upper())
        media=record_index.get(key if row['slot']!='-' else (row['champion'].lower(),'P'))
        if not media:
            missing.append(f"{row['id']}: no matching manifest record")
            checks.append({'id':row['id'],'chosen':'MISSING','source':''})
            continue
        slug=row['champion'].lower()
        if row['level']=='L1':
            sourcepath=DOWNLOADS/media['portrait_local']
            if not sourcepath.is_file():
                missing.append(f"{row['id']}: missing portrait")
                checks.append({'id':row['id'],'chosen':'MISSING','source':'portrait'})
                continue
            ext=sourcepath.suffix.lower()
            rel=pathlib.Path('media/champions')/f'{slug}_portrait{ext}'
            row['media_path']=copy_to(sourcepath,rel)
            row['media_type']='portrait'
            # Avoid a hard-coded JPG assumption in the existing v4 card back.
            row['icon_path']=row['media_path']
            chosen='portrait'
        else:
            icon=DOWNLOADS/media['icon_local'] if media['icon_local'] else None
            if not icon or not icon.is_file():
                missing.append(f"{row['id']}: icon missing")
                checks.append({'id':row['id'],'chosen':'MISSING','source':'icon'})
                continue
            iconrel=pathlib.Path('media/abilities')/f'{slug}_{row["slot"].lower()}_icon.png'
            row['icon_path']=copy_to(icon,iconrel)
            if row['slot']=='P':
                row['media_type']='icon'; row['media_path']=row['icon_path']
                chosen='icon (passive by design)'
            else:
                candidate=DOWNLOADS/media['video_local'] if media['video_local'] else None
                if candidate and candidate.is_file() and candidate.suffix.lower()=='.gif':
                    gifrel=pathlib.Path('media/gifs')/f'{slug}_{row["slot"].lower()}.gif'
                    row['media_type']='gif';row['media_path']=copy_to(candidate,gifrel)
                    chosen='gif'
                else:
                    row['media_type']='icon';row['media_path']=row['icon_path']
                    row['front_hint']=f'{row["champion"].upper()} · {row["slot"]} · ICON FALLBACK'
                    chosen='icon fallback; check Riot clip manually'
                poster=DOWNLOADS/media['poster_local'] if media['poster_local'] else None
                if poster and poster.is_file():
                    row['poster_path']=copy_to(poster,pathlib.Path('media/posters')/f'{slug}_{row["slot"].lower()}_poster.jpg')
        checks.append({'id':row['id'],'chosen':chosen,'source':media.get('video_source_url','')})
        row['review_status']='Editorial draft · manually verify media and gameplay patch'
        changes.append(row)
    write_csv(REPORT,checks,['id','chosen','source'])
    if missing:
        print('\nERROR: Missing required assets. No cards.csv changes. See batch01/media_check.csv')
        for m in missing: print(' - '+m)
        return 3
    chosen={r['id']:r for r in changes}
    old_ids={r['id'] for r in existing}
    replaced=[(chosen.pop(row['id']) if row['id'] in chosen else row) for row in existing]
    added=list(chosen.values())
    final=replaced+added
    assert len({r['id'] for r in final})==len(final)
    backup=ROOT/'cards_before_batch01_backup.csv'
    if not backup.exists():shutil.copy2(MASTER,backup)
    write_csv(MASTER,final,mastercols)
    print(f'OK: merged {len(changes)} batch cards; added {len(added)}; master now {len(final)} cards.')
    print('Media choices: '+', '.join(f'{k}={sum(c["chosen"].startswith(k) for c in checks)}' for k in ['portrait','gif','icon']))
    print('WARNING: gameplay/visual review still needed. See batch01/media_check.csv and review_queue.csv')
    print('Stable IDs and previous 64 cards preserved. Run build_deck.py to create APKG.')
    return 0

if __name__=='__main__':sys.exit(main())
