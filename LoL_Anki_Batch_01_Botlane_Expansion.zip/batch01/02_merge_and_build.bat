@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 prepare_batch.py
) else (
  python prepare_batch.py
)
if errorlevel 1 goto fail
cd /d "%~dp0.."
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 build_deck.py
) else (
  python build_deck.py
)
if errorlevel 1 goto fail
copy /y "LoL_Anki_Pilot_6_Champions_v4_English.apkg" "LoL_Anki_Batch_01_100_Cards.apkg" >nul
if errorlevel 1 goto fail
echo.
echo Done: LoL_Anki_Batch_01_100_Cards.apkg
pause
exit /b 0
:fail
echo.
echo ERROR. Read the messages above; original cards.csv was backed up if updated.
pause
exit /b 1
