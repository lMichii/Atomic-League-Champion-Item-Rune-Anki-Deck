@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 media_fetcher.py --champions Caitlyn,Ashe,Jinx,Leona,Lux,Morgana --patch 16.21.1 --video-format gif --output downloads
) else (
  python media_fetcher.py --champions Caitlyn,Ashe,Jinx,Leona,Lux,Morgana --patch 16.21.1 --video-format gif --output downloads
)
if errorlevel 1 (
  echo.
  echo Download failed: check messages above.
) else (
  echo.
  echo Download ready. Review the clips, then run 02_merge_and_build.bat
)
pause
