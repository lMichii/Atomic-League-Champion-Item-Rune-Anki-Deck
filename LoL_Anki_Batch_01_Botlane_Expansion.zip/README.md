# LoL Anki · Production Batch 01 (Botlane fundamentals)

**English cards, unchanged v4 card design.** Six additions: **Caitlyn, Ashe, Jinx, Leona, Lux and Morgana**. The batch has **6 L1 champion overview cards + 30 L2 P/Q/W/E/R cards**. Once merged with the 64-card v4 base, the output contains **100 cards**, without automatic reverse cards or newly invented cooldown numbers.

## Import into your already-working v4 project

1. **Back up your Anki collection.** Keep your v4 project folder (the one with `cards.csv`, `build_deck.py`, `anki_template.anki2` and `media/`).
2. Unzip this bundle and **copy the entire `batch01/` folder into that v4 folder**. Your project should now have `cards.csv` and a `batch01/` subfolder.
3. Double-click `batch01/01_fetch_media.bat`. Internet and Python are required; **FFmpeg** is needed to convert the Riot videos to GIFs. The downloads will go into `batch01/downloads/` and will not touch your existing videos.
4. Review the GIFs, passive icons and any fallbacks in `batch01/downloads/media/`, using `batch01/review_queue.csv` and the source URLs. **Pay special attention to Caitlyn P, Jinx P, Lux P visual cues.** Passive icons are intentionally the default until a useful visual cue has been personally confirmed.
5. Double-click `batch01/02_merge_and_build.bat`. The script checks media availability, copies the assets into the v4 `media/` folder, merges 36 new rows into `cards.csv` with stable IDs and exports `LoL_Anki_Batch_01_100_Cards.apkg` in the v4 project root. The previous master CSV is backed up as `cards_before_batch01_backup.csv`.
6. Import the new APKG. Verify the existing learned notes retain their progress, and check new media playback in Anki. The original note model and GUID algorithm are unchanged.

### Rules to keep

- **L1:** One portrait and one beginner-friendly overview per champion, short question: `What can this champion do?`. Back shows `Build focus: AP/AD/Health, Armor, MR` and **Counterplay**.
- **L2:** Active spells use looping GIF front; P uses icon plus optional *verified* in-game visual cue. Champion name is always on passive fronts. Back includes icon + spell slot + explanation + counterplay. No reverse cards.
- **L2 cooldowns:** Separate A-priority timer card **only when a matchup-relevant timing is checked against the current Wiki patch**. No speculative timings in Batch 01.
- **L3:** Not started; exact champion stats, damage, scalings and cooldown arrays require patch-level verification.
- Color-coded stat terms and minimal v4 CSS are inherited directly from `build_deck.py`.

### Safety / QA

These 36 entries are **editorial drafts** grounded in Riot's official champion ability descriptions and linked Wiki pages. Media quality and patch correctness must be checked before treating the cards as final. The script intentionally uses an icon fallback when the current official video is unavailable rather than inventing a GIF.

### Direct editing

`batch01/new_cards.csv` is the editable set of **new** cards; the production workbook `LoL_Anki_Batch_01_Production.xlsx` is the human-friendly editing/review sheet. If you edit the workbook, also copy the changes to `new_cards.csv` before rebuilding (the generator consumes CSV). Card IDs must never change once imported. Edit English descriptions freely, but do not change the field order.
